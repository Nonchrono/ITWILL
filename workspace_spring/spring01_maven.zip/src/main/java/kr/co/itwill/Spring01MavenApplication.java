package kr.co.itwill;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring01MavenApplication {

	public static void main(String[] args) {
		SpringApplication.run(Spring01MavenApplication.class, args);
	}

}
