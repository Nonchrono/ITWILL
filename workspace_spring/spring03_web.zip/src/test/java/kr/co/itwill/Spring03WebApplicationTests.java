package kr.co.itwill;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring03WebApplicationTests {

	@Test
	void contextLoads() {
	}

}
